clientCallbacks = vx.createCallbackProxy()
