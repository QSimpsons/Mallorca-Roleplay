SharedConfig = {}
SharedConfig.currencySymbol = "€"
