local Components = {
  {label = _U('sex'),                   name = 'sex',           value = 0,  min = 0,  zoomOffset = 0.6,   camOffset = 0.65},
  {label = _U('face'),                  name = 'face',          value = 0,  min = 0,  zoomOffset = 0.6,   camOffset = 0.65},
  {label = _U('skin'),                  name = 'skin',          value = 0,  min = 0,  zoomOffset = 0.6,   camOffset = 0.65},
  {label = _U('wrinkles'),              name = 'age_1',         value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('wrinkle_thickness'),     name = 'age_2',         value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('beard_type'),            name = 'beard_1',       value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('beard_size'),            name = 'beard_2',       value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('beard_color_1'),         name = 'beard_3',       value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('beard_color_2'),         name = 'beard_4',       value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('hair_1'),                name = 'hair_1',        value = 0,  min = 0,  zoomOffset = 0.6,   camOffset = 0.65},
  {label = _U('hair_2'),                name = 'hair_2',        value = 0,  min = 0,  zoomOffset = 0.6,   camOffset = 0.65},
  {label = _U('hair_color_1'),          name = 'hair_color_1',  value = 0,  min = 0,  zoomOffset = 0.6,   camOffset = 0.65},
  {label = _U('hair_color_2'),          name = 'hair_color_2',  value = 0,  min = 0,  zoomOffset = 0.6,   camOffset = 0.65},
  {label = _U('eyebrow_size'),          name = 'eyebrows_2',    value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('eyebrow_type'),          name = 'eyebrows_1',    value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('eyebrow_color_1'),       name = 'eyebrows_3',    value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('eyebrow_color_2'),       name = 'eyebrows_4',    value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('makeup_type'),           name = 'makeup_1',      value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('makeup_thickness'),      name = 'makeup_2',      value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('makeup_color_1'),        name = 'makeup_3',      value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('makeup_color_2'),        name = 'makeup_4',      value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('lipstick_type'),         name = 'lipstick_1',    value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('lipstick_thickness'),    name = 'lipstick_2',    value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('lipstick_color_1'),      name = 'lipstick_3',    value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('lipstick_color_2'),      name = 'lipstick_4',    value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('ear_accessories'),       name = 'ears_1',        value = -1, min = -1, zoomOffset = 0.4,   camOffset = 0.65},
  {label = _U('ear_accessories_color'), name = 'ears_2',        value = 0,  min = 0,  zoomOffset = 0.4,   camOffset = 0.65, textureof = 'ears_1'},
  {label = _U('tshirt_1'),              name = 'tshirt_1',      value = 0,  min = 0,  zoomOffset = 0.75,  camOffset = 0.15},
  {label = _U('tshirt_2'),              name = 'tshirt_2',      value = 0,  min = 0,  zoomOffset = 0.75,  camOffset = 0.15, textureof = 'tshirt_1'},
  {label = _U('torso_1'),               name = 'torso_1',       value = 0,  min = 0,  zoomOffset = 0.75,  camOffset = 0.15},
  {label = _U('torso_2'),               name = 'torso_2',       value = 0,  min = 0,  zoomOffset = 0.75,  camOffset = 0.15, textureof = 'torso_1'},
  {label = _U('decals_1'),              name = 'decals_1',      value = 0,  min = 0,  zoomOffset = 0.75,  camOffset = 0.15}, 
  {label = _U('decals_2'),              name = 'decals_2',      value = 0,  min = 0,  zoomOffset = 0.75,  camOffset = 0.15, textureof = 'decals_1'},
  {label = _U('arms'),                  name = 'arms',          value = 0,  min = 0,  zoomOffset = 0.75,  camOffset = 0.15},
  {label = _U('pants_1'),               name = 'pants_1',       value = 0,  min = 0,  zoomOffset = 0.8,   camOffset = -0.5},
  {label = _U('pants_2'),               name = 'pants_2',       value = 0,  min = 0,  zoomOffset = 0.8,   camOffset = -0.5, textureof = 'pants_1'},
  {label = _U('shoes_1'),               name = 'shoes_1',       value = 0,  min = 0,  zoomOffset = 0.8,   camOffset = -0.8},
  {label = _U('shoes_2'),               name = 'shoes_2',       value = 0,  min = 0,  zoomOffset = 0.8,   camOffset = -0.8, textureof = 'shoes_1'},
  {label = _U('mask_1'),                name = 'mask_1',        value = 0,  min = 0,  zoomOffset = 0.6,   camOffset = 0.65},
  {label = _U('mask_2'),                name = 'mask_2',        value = 0,  min = 0,  zoomOffset = 0.6,   camOffset = 0.65, textureof = 'mask_1'},
  {label = _U('bproof_1'),              name = 'bproof_1',      value = 0,  min = 0,  zoomOffset = 0.75,  camOffset = 0.15},
  {label = _U('bproof_2'),              name = 'bproof_2',      value = 0,  min = 0,  zoomOffset = 0.75,  camOffset = 0.15, textureof = 'bproof_1'},
  {label = _U('chain_1'),               name = 'chain_1',       value = 0,  min = 0,  zoomOffset = 0.6,   camOffset = 0.65},
  {label = _U('chain_2'),               name = 'chain_2',       value = 0,  min = 0,  zoomOffset = 0.6,   camOffset = 0.65, textureof = 'chain_1'},
  {label = _U('helmet_1'),              name = 'helmet_1',      value = -1, min = -1, zoomOffset = 0.6,   camOffset = 0.65, componentId = 0 },
  {label = _U('helmet_2'),              name = 'helmet_2',      value = 0,  min = 0,  zoomOffset = 0.6,   camOffset = 0.65, textureof = 'helmet_1'},
  {label = _U('glasses_1'),             name = 'glasses_1',     value = -1,  min = -1,  zoomOffset = 0.6,   camOffset = 0.65},
  {label = _U('glasses_2'),             name = 'glasses_2',     value = 0,  min = 0,  zoomOffset = 0.6,   camOffset = 0.65, textureof = 'glasses_1'},
  {label = _U('bag'),                   name = 'bags_1',        value = 0,  min = 0,  zoomOffset = 0.75,  camOffset = 0.15},
  {label = _U('bag_color'),             name = 'bags_2',        value = 0,  min = 0,  zoomOffset = 0.75,  camOffset = 0.15, textureof = 'bags_1'}
}

local LastSex       = -1
local LoadSkin      = nil
local LoadClothes   = nil
local Character     = {}
local reapplyOutfit = false

for i=1, #Components, 1 do
  Character[Components[i].name] = Components[i].value
end

local function MarkOutfitForReapply()
  reapplyOutfit = true
end

local function LoadPedModel(modelHash, cb)
  RequestModel(modelHash)

  Citizen.CreateThread(function()
    local timeoutAt = GetGameTimer() + 5000

    while not HasModelLoaded(modelHash) and GetGameTimer() < timeoutAt do
      RequestModel(modelHash)
      Citizen.Wait(0)
    end

    if HasModelLoaded(modelHash) and IsModelInCdimage(modelHash) and IsModelValid(modelHash) then
      SetPlayerModel(PlayerId(), modelHash)
      -- SetPlayerModel spawns a new ped in default clothes. The saved outfit is
      -- applied to that new ped from skinchanger:modelLoaded, before the callback.
      SetPedDefaultComponentVariation(PlayerPedId())
      SetModelAsNoLongerNeeded(modelHash)
    end

    TriggerEvent('skinchanger:modelLoaded')

    if cb ~= nil then
      cb()
    end
  end)
end

function LoadDefaultModel(malePed, cb)
  local characterModel

  if malePed then
    characterModel = GetHashKey('mp_m_freemode_01')
  else
    characterModel = GetHashKey('mp_f_freemode_01')
  end

  LoadPedModel(characterModel, cb)
end

function GetMaxVals()

  local playerPed = GetPlayerPed(-1)

  local data = {
    sex           = 332,
    face          = 45,
    skin          = 45,
    age_1         = GetNumHeadOverlayValues(3)-1,
    age_2         = 10,
    beard_1       = GetNumHeadOverlayValues(1)-1,
    beard_2       = 10,
    beard_3       = GetNumHairColors()-1,
    beard_4       = GetNumHairColors()-1,
    hair_1        = GetNumberOfPedDrawableVariations(playerPed, 2) - 1,
    hair_2        = GetNumberOfPedTextureVariations(playerPed, 2, Character['hair_1']) - 1,
    hair_color_1  = GetNumHairColors()-1,
    hair_color_2  = GetNumHairColors()-1,
    eyebrows_1    = GetNumHeadOverlayValues(2)-1,
    eyebrows_2    = 10,
    eyebrows_3    = GetNumHairColors()-1,
    eyebrows_4    = GetNumHairColors()-1,
    makeup_1      = GetNumHeadOverlayValues(4)-1,
    makeup_2      = 10,
    makeup_3      = GetNumHairColors()-1,
    makeup_4      = GetNumHairColors()-1,
    lipstick_1    = GetNumHeadOverlayValues(8)-1,
    lipstick_2    = 10,
    lipstick_3    = GetNumHairColors()-1,
    lipstick_4    = GetNumHairColors()-1,
    ears_1        = GetNumberOfPedPropDrawableVariations  (playerPed, 1) - 1,
    ears_2        = GetNumberOfPedPropTextureVariations   (playerPed, 1, Character['ears_1'] - 1),
    tshirt_1      = GetNumberOfPedDrawableVariations      (playerPed, 8) - 1,
    tshirt_2      = GetNumberOfPedTextureVariations       (playerPed, 8, Character['tshirt_1']) - 1,
    torso_1       = GetNumberOfPedDrawableVariations      (playerPed, 11) - 1,
    torso_2       = GetNumberOfPedTextureVariations       (playerPed, 11, Character['torso_1']) - 1,
    decals_1      = GetNumberOfPedDrawableVariations      (playerPed, 10) - 1,
    decals_2      = GetNumberOfPedTextureVariations       (playerPed, 10, Character['decals_1']) - 1,
    arms          = GetNumberOfPedDrawableVariations      (playerPed, 3) - 1,
    pants_1       = GetNumberOfPedDrawableVariations      (playerPed, 4) - 1,
    pants_2       = GetNumberOfPedTextureVariations       (playerPed, 4, Character['pants_1']) - 1,
    shoes_1       = GetNumberOfPedDrawableVariations      (playerPed, 6) - 1,
    shoes_2       = GetNumberOfPedTextureVariations       (playerPed, 6, Character['shoes_1']) - 1,
    mask_1        = GetNumberOfPedDrawableVariations      (playerPed, 1) - 1,
    mask_2        = GetNumberOfPedTextureVariations       (playerPed, 1, Character['mask_1']) - 1,
    bproof_1      = GetNumberOfPedDrawableVariations      (playerPed, 9) - 1,
    bproof_2      = GetNumberOfPedTextureVariations       (playerPed, 9, Character['bproof_1']) - 1,
    chain_1       = GetNumberOfPedDrawableVariations      (playerPed, 7) - 1,
    chain_2       = GetNumberOfPedTextureVariations       (playerPed, 7, Character['chain_1']) - 1,
    bags_1        = GetNumberOfPedDrawableVariations      (playerPed, 5) - 1,
    bags_2        = GetNumberOfPedTextureVariations       (playerPed, 5, Character['bags_1']) - 1,
    helmet_1      = GetNumberOfPedPropDrawableVariations  (playerPed, 0) - 1,
    helmet_2      = GetNumberOfPedPropTextureVariations   (playerPed, 0, Character['helmet_1']) - 1,
    glasses_1     = GetNumberOfPedPropDrawableVariations  (playerPed, 1) - 1,
    glasses_2     = GetNumberOfPedPropTextureVariations   (playerPed, 1, Character['glasses_1'] - 1),
  }

  return data

end

function ApplySkin(skin, clothes)

  local playerPed = GetPlayerPed(-1)

  for k,v in pairs(skin) do
    Character[k] = v
  end

  if clothes ~= nil then

    for k,v in pairs(clothes) do
      if
        k ~= 'sex'          and
        k ~= 'face'         and
        k ~= 'skin'         and
        k ~= 'age_1'        and
        k ~= 'age_2'        and
        k ~= 'beard_1'      and
        k ~= 'beard_2'      and
        k ~= 'beard_3'      and
        k ~= 'beard_4'      and
        k ~= 'hair_1'       and
        k ~= 'hair_2'       and
        k ~= 'hair_color_1' and
        k ~= 'hair_color_2' and
        k ~= 'eyebrows_1'   and
        k ~= 'eyebrows_2'   and
        k ~= 'eyebrows_3'   and
        k ~= 'eyebrows_4'   and
        k ~= 'makeup_1'     and
        k ~= 'makeup_2'     and
        k ~= 'makeup_3'     and
        k ~= 'makeup_4'     and
        k ~= 'lipstick_1'   and
        k ~= 'lipstick_2'   and
        k ~= 'lipstick_3'   and
        k ~= 'lipstick_4'
      then
        Character[k] = v
      end
    end

  end

  local face = Character['face']
  if type(face) ~= 'number' then
    face = Character['mom'] or 0
  end

  local skinTone = Character['skin']
  if type(skinTone) ~= 'number' then
    skinTone = Character['dad'] or 0
  end

  SetPedHeadBlendData     (playerPed, face, face, face, skinTone, skinTone, skinTone, 1.0, 1.0, 1.0, true)

  SetPedHairColor         (playerPed,       Character['hair_color_1'] or 0, Character['hair_color_2'] or 0) -- Hair Color
  SetPedHeadOverlay       (playerPed, 3,    Character['age_1'],         ((Character['age_2'] or 0) / 10) + 0.0)      -- Age + opacity
  SetPedHeadOverlay       (playerPed, 1,    Character['beard_1'],       ((Character['beard_2'] or 0) / 10) + 0.0)    -- Beard + opacity
  SetPedHeadOverlay       (playerPed, 2,    Character['eyebrows_1'],    ((Character['eyebrows_2'] or 0) / 10) + 0.0) -- Eyebrows + opacity
  SetPedHeadOverlay       (playerPed, 4,    Character['makeup_1'],      ((Character['makeup_2'] or 0) / 10) + 0.0)   -- Makeup + opacity
  SetPedHeadOverlay       (playerPed, 8,    Character['lipstick_1'],    ((Character['lipstick_2'] or 0) / 10) + 0.0) -- Lipstick + opacity
  SetPedComponentVariation(playerPed, 2,    Character['hair_1'] or 0,    Character['hair_2'] or 0, 2)              -- Hair
  SetPedHeadOverlayColor  (playerPed, 1, 1, Character['beard_3'] or 0,    Character['beard_4'] or 0)                -- Beard Color
  SetPedHeadOverlayColor  (playerPed, 2, 1, Character['eyebrows_3'] or 0, Character['eyebrows_4'] or 0)             -- Eyebrows Color
  SetPedHeadOverlayColor  (playerPed, 4, 1, Character['makeup_3'] or 0,   Character['makeup_4'] or 0)               -- Makeup Color
  SetPedHeadOverlayColor  (playerPed, 8, 1, Character['lipstick_3'] or 0, Character['lipstick_4'] or 0)             -- Lipstick Color

  local function applyProp(propId, drawable, texture)
    if type(drawable) ~= 'number' then
      return
    end

    if drawable == -1 then
      ClearPedProp(playerPed, propId)
    else
      SetPedPropIndex(playerPed, propId, drawable, texture or 0, 2)
    end
  end

  applyProp(2, Character['ears_1'], Character['ears_2'])

  SetPedComponentVariation(playerPed, 8,  Character['tshirt_1'] or 0,  Character['tshirt_2'] or 0, 2)     -- Tshirt
  SetPedComponentVariation(playerPed, 11, Character['torso_1'] or 0,   Character['torso_2'] or 0, 2)      -- torso parts
  SetPedComponentVariation(playerPed, 3,  Character['arms'] or 0,      Character['arms_2'] or 0, 2)       -- arms
  SetPedComponentVariation(playerPed, 10, Character['decals_1'] or 0,  Character['decals_2'] or 0, 2)     -- decals
  SetPedComponentVariation(playerPed, 4,  Character['pants_1'] or 0,   Character['pants_2'] or 0, 2)      -- pants
  SetPedComponentVariation(playerPed, 6,  Character['shoes_1'] or 0,   Character['shoes_2'] or 0, 2)      -- shoes
  SetPedComponentVariation(playerPed, 1,  Character['mask_1'] or 0,    Character['mask_2'] or 0, 2)       -- mask
  SetPedComponentVariation(playerPed, 9,  Character['bproof_1'] or 0,  Character['bproof_2'] or 0, 2)     -- bulletproof
  SetPedComponentVariation(playerPed, 7,  Character['chain_1'] or 0,   Character['chain_2'] or 0, 2)      -- chain
  SetPedComponentVariation(playerPed, 5,  Character['bags_1'] or 0,    Character['bags_2'] or 0, 2)       -- Bag

  applyProp(0, Character['helmet_1'], Character['helmet_2'])
  applyProp(1, Character['glasses_1'], Character['glasses_2'])
  applyProp(6, Character['watches_1'], Character['watches_2'])
  applyProp(7, Character['bracelets_1'], Character['bracelets_2'])

end

AddEventHandler('skinchanger:loadDefaultModel', function(loadMale, cb)
  LoadDefaultModel(loadMale, cb)
end)

AddEventHandler('skinchanger:getData', function(cb)

  local components = json.decode(json.encode(Components))

  for k,v in pairs(Character) do
    for i=1, #components, 1 do
      if k == components[i].name then
        components[i].value = v
        --components[i].zoomOffset = Components[i].zoomOffset
        --components[i].camOffset = Components[i].camOffset
      end
    end
  end

  cb(components, GetMaxVals())
end)

AddEventHandler('skinchanger:change', function(key, val)

  Character[key] = val

  if key == 'sex' then
    TriggerEvent('skinchanger:loadSkin', Character)
  else
    ApplySkin(Character)
  end

end)

AddEventHandler('skinchanger:getSkin', function(cb)
  cb(Character)
end)

AddEventHandler('skinchanger:modelLoaded', function()

  ClearPedProp(PlayerPedId(), 0)

  if LoadSkin ~= nil then

    ApplySkin(LoadSkin)
    LoadSkin = nil

  end

  if LoadClothes ~= nil then

    ApplySkin(LoadClothes.playerSkin, LoadClothes.clothesSkin)
    LoadClothes = nil

  end

end)

local pedClothes = {
  { key = 'mask_1', key2 = 'mask_2', id = 1 },
  { key = 'hair_1', key2 = 'hair_2', id = 2 },
  { key = 'arms', key2 = 'arms_2', id = 3 },
  { key = 'pants_1', key2 = 'pants_2', id = 4 },
  { key = 'bags_1', key2 = 'bags_2', id = 5 },
  { key = 'shoes_1', key2 = 'shoes_2', id = 6 },
  { key = 'chain_1', key2 = 'chain_2', id = 7 },
  { key = 'tshirt_1', key2 = 'tshirt_2', id = 8 },
  { key = 'bproof_1', key2 = 'bproof_2', id = 9 },
  { key = 'decals_1', key2 = 'decals_2', id = 10 },
  { key = 'torso_1', key2 = 'torso_2', id = 11 },
}

local pedProps = {
  { key = 'helmet_1', key2 = 'helmet_2', id = 0 },
  { key = 'glasses_1', key2 = 'glasses_2', id = 1 },
  { key = 'ears_1', key2 = 'ears_2', id = 2 },
  { key = 'watches_1', key2 = 'watches_2', id = 6 },
  { key = 'bracelets_1', key2 = 'bracelets_2', id = 7 },
}

local function isBlankOutfit(data)
  return (data['torso_1'] or 0) == 0
    and (data['pants_1'] or 0) == 0
    and (data['shoes_1'] or 0) == 0
    and (data['tshirt_1'] or 0) == 0
end

function CaptureWornOutfit()
  local ped = PlayerPedId()

  if ped == 0 or not DoesEntityExist(ped) then
    return Character
  end

  local captured = {}

  for i = 1, #pedClothes do
    local item = pedClothes[i]
    captured[item.key] = GetPedDrawableVariation(ped, item.id)
    captured[item.key2] = GetPedTextureVariation(ped, item.id)
  end

  if isBlankOutfit(captured) and not isBlankOutfit(Character) then
    return Character
  end

  local model = GetEntityModel(ped)

  if model == GetHashKey('mp_m_freemode_01') then
    Character['sex'] = 0
  elseif model == GetHashKey('mp_f_freemode_01') then
    Character['sex'] = 1
  end

  for i = 1, #pedClothes do
    local item = pedClothes[i]
    Character[item.key] = captured[item.key]
    Character[item.key2] = captured[item.key2]
  end

  for i = 1, #pedProps do
    local item = pedProps[i]
    local drawable = GetPedPropIndex(ped, item.id)
    Character[item.key] = drawable
    Character[item.key2] = drawable == -1 and 0 or GetPedPropTextureIndex(ped, item.id)
  end

  local hairRead, hairColor, hairHighlight = pcall(function()
    return GetPedHairColor(ped), GetPedHairHighlightColor(ped)
  end)

  if hairRead and type(hairColor) == 'number' then
    Character['hair_color_1'] = hairColor
  end

  if hairRead and type(hairHighlight) == 'number' then
    Character['hair_color_2'] = hairHighlight
  end

  return Character
end

local function loadCharacterModel(sex, cb)
  if sex == 0 then
    LoadDefaultModel(true, cb)
  elseif sex > 1 and pedList and pedList[sex - 1] then
    LoadPedModel(GetHashKey(pedList[sex - 1]), cb)
  else
    LoadDefaultModel(false, cb)
  end
end

RegisterNetEvent('skinchanger:loadSkin')
AddEventHandler('skinchanger:loadSkin', function(skin, cb)
  if type(skin) ~= 'table' then
    if cb then cb() end
    return
  end

  skin.sex = skin.sex or 0
  MarkOutfitForReapply()

  if skin.sex ~= LastSex then
    LoadSkin = skin
    LastSex = skin.sex
    loadCharacterModel(skin.sex, cb)
  else
    ApplySkin(skin)
    if cb then cb() end
  end
end)

RegisterNetEvent('skinchanger:loadClothes')
AddEventHandler('skinchanger:loadClothes', function(playerSkin, clothesSkin)
  if type(playerSkin) ~= 'table' then
    return
  end

  playerSkin.sex = playerSkin.sex or 0
  MarkOutfitForReapply()

  if playerSkin.sex ~= LastSex then
    LoadClothes = {
      playerSkin = playerSkin,
      clothesSkin = clothesSkin
    }
    LastSex = playerSkin.sex
    loadCharacterModel(playerSkin.sex)
  else
    ApplySkin(playerSkin, clothesSkin)
  end
end)

AddEventHandler('playerSpawned', function()
  if not reapplyOutfit then
    return
  end

  reapplyOutfit = false

  -- NetworkResurrectLocalPlayer runs during spawn and puts the freemode ped
  -- back in default clothes. Put the saved outfit back on once that is done.
  Citizen.SetTimeout(400, function()
    if LastSex ~= -1 then
      ApplySkin(Character)
    end
  end)
end)

exports('GetSkin', function()
  return CaptureWornOutfit()
end)
