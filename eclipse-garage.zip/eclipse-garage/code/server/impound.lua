local existingVehiclesCache = {}
local VEHICLE_ENTITY_TYPE = 2

esrp_lib.callback.register("vx_garage:getExistingVehicles", function()
    return existingVehiclesCache
end)

esrp_lib.callback.register("vx_garage:returnFromImpound", function(playerId, plate)
    local player = esrp_lib.player.getFromId(playerId)
    local identifier = player:getIdentifier()
    local vehicle = functions.getVehicleByPlate(plate)

    if vehicle.owner ~= identifier then
        return false
    end

    player:removeAccountMoney("bank", Config.impoundPrice)

    MySQL.update("UPDATE owned_vehicles SET `pound` = false WHERE `plate` = @plate", {
        ["@plate"] = plate
    })

    return true
end)

esrp_lib.callback.register("vx_garage:storedVehicle", function(playerId, plate)
    Citizen.Wait(2000)

    local player = esrp_lib.player.getFromId(playerId)
    local identifier = player:getIdentifier()
    local vehicle = functions.getVehicleByPlate(plate)

    if vehicle.owner ~= identifier then
        return false
    end

    MySQL.update("UPDATE owned_vehicles SET `pound` = false WHERE `plate` = @plate", {
        ["@plate"] = plate
    })

    return true
end)

RegisterNetEvent("entityCreated", function(entity)

    if GetEntityType(entity) ~= VEHICLE_ENTITY_TYPE then
        return
    end

    local plate = GetVehicleNumberPlateText(entity)
    plate = plate:gsub("%s+", "")

    local vehicle = functions.getVehicleByPlate(plate)
    if vehicle then
        table.insert(existingVehiclesCache, {
            plate = plate,
            networkId = entity
        })
        -- esrp_lib.print.info("added vehicle to cache", plate)
    else
        -- esrp_lib.print.info("unable to find vehicle in database", plate)
    end
end)

RegisterNetEvent("entityRemoved", function(entity)

    if GetEntityType(entity) ~= VEHICLE_ENTITY_TYPE then
        return
    end

    local plate = GetVehicleNumberPlateText(entity)
    if not plate then return end

    local foundInCache = false
    for i, cachedVehicle in pairs(existingVehiclesCache) do
        if cachedVehicle.networkId == entity then
            foundInCache = true
            break
        end
    end

    if not foundInCache then
        return
    end

    MySQL.update("UPDATE owned_vehicles SET `pound` = true WHERE `plate` = @plate", {
        ["@plate"] = plate
    })

    for i, cachedVehicle in pairs(existingVehiclesCache) do
        if cachedVehicle.networkId == entity then
            table.remove(existingVehiclesCache, i)
            break
        end
    end
end)