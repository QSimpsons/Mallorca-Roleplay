functions = {}

function functions.ownerId(src)
    if ESX and ESX.GetPlayerFromId then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer and xPlayer.identifier and xPlayer.identifier ~= '' then
            return xPlayer.identifier
        end
    end
    if esrp_lib and esrp_lib.player and esrp_lib.player.getIdentifier then
        return esrp_lib.player.getIdentifier(src, true)
    end
    return nil
end

function functions.getVehicleByPlate(plate)
    local result = MySQL.query.await("SELECT * FROM owned_vehicles WHERE `plate` = @plate", {
        ["@plate"] = plate
    })
    local vehicle = result[1]
    return vehicle
end
